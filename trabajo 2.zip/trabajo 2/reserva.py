from excepciones import ErrorEnReserva
import datetime

def guardar_log(texto):
    with open("bitacora.txt", "a", encoding="utf-8") as f:
        f.write(f"[{datetime.datetime.now()}] {texto}\n")

class Reserva:

    def __init__(self, cliente, servicio, tiempo):
        self._cliente = cliente
        self._servicio = servicio
        self._tiempo = tiempo
        self._estado = "Creada"

    def confirmar(self):
        self._estado = "Confirmada"
        guardar_log(f"Reserva confirmada para {self._cliente.nombres}")

    def cancelar(self):
        self._estado = "Cancelada"
        guardar_log(f"Reserva cancelada para {self._cliente.nombres}")

    def procesar(self):
        try:
            if not self._cliente or not self._servicio:
                raise ErrorEnReserva("Datos incompletos")

            if self._tiempo <= 0:
                raise ErrorEnReserva("Tiempo inválido")

            total = self._servicio.calcular_total(self._tiempo)

        except Exception as e:
            self._estado = "Fallida"
            guardar_log(f"Error en reserva: {e}")
            raise ErrorEnReserva("No se pudo procesar la reserva")

        else:
            self.confirmar()
            return f"Reserva confirmada. Pago: ${total}"

        finally:
            guardar_log("Proceso de reserva finalizado")
