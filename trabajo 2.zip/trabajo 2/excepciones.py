# Función: Definir errores personalizados para el control del programa.
# Por qué está aquí: La guía exige manejar excepciones para que el sistema no muera ante un dato mal ingresado.
class ErrorDeNegocio(Exception):
    pass

class ErrorEnReserva(ErrorDeNegocio):
    pass

class ErrorDeNombres(ErrorDeNegocio):
    pass

class ErrorDeApellidos(ErrorDeNegocio):
    pass

class ErrorDeDocumento(ErrorDeNegocio):
    pass

class ErrorDeTelefono(ErrorDeNegocio):
    pass