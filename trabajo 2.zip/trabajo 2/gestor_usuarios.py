from cliente import Cliente
from excepciones import ErrorDeDocumento
import datetime

def guardar_log(texto):
    with open("bitacora.txt", "a", encoding="utf-8") as f:
        f.write(f"[{datetime.datetime.now()}] {texto}\n")

class GestorUsuarios:

    def __init__(self):
        self._lista = []
        self._precargar()

    def _precargar(self):
        datos = [
            ("John", "Alvarez", "1010", "3000000000", "Anserma"),
            ("Leonardo", "Alvarez", "2020", "3100000000", "Anserma"),
            ("Cesar", "Giraldo", "3030", "3200000000", "Anserma"),
            ("Jenny", "Aricapa", "4040", "3300000000", "Anserma")
        ]
        for d in datos:
            try:
                self._lista.append(Cliente(*d))
            except Exception as e:
                guardar_log(f"Error precarga: {e}")

    def buscar(self, cedula):
        return next((c for c in self._lista if c.documento_identidad == cedula), None)

    def registrar(self, n, a, d, t, dir):
        try:
            if self.buscar(d):
                raise ErrorDeDocumento("Documento ya registrado")

            cliente = Cliente(n, a, d, t, dir)

        except Exception as e:
            guardar_log(f"Error registrando {d}: {e}")
            raise

        else:
            self._lista.append(cliente)
            guardar_log(f"Cliente registrado: {d}")
            return cliente

        finally:
            guardar_log("Fin de registro")
